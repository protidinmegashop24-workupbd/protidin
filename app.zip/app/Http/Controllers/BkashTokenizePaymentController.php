<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Karim007\LaravelBkashTokenize\Facade\BkashPaymentTokenize;
use Karim007\LaravelBkashTokenize\Facade\BkashRefundTokenize;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\Deposit;
use App\Models\BkashSetting;

class BkashTokenizePaymentController extends Controller
{
    public function index()
    {
        return view('bkashT::bkash-payment');
    }

    public function createPayment(Request $request)
    {
        // অ্যাডমিন সেটিংস থেকে min_amount ফেচ করা
        $bkashSettings = BkashSetting::first();
        $minAmount = $bkashSettings->min_amount ?? 10.00; // ডিফল্ট 10.00

        // ফর্মের amount ভ্যালিডেট করা
        $validatedData = $request->validate([
            'amount' => "required|numeric|min:{$minAmount}", // সেটিংস থেকে min_amount ব্যবহার করা
        ]);

        // ইউনিক ইনভয়েস আইডি জেনারেট করা
        $inv = uniqid();
        
        // পেমেন্ট রিকোয়েস্ট ডেটা সেটআপ করা
        $paymentData = [
            'intent' => 'sale',
            'mode' => '0011', // 0011 for checkout
            'payerReference' => $inv,
            'currency' => 'BDT',
            'amount' => $validatedData['amount'], // ফর্ম থেকে amount ব্যবহার করা
            'merchantInvoiceNumber' => $inv,
            'callbackURL' => config("bkash.callbackURL"), // কনফিগারেশন থেকে callback URL
        ];

        // পেমেন্ট ডেটা JSON এ কনভার্ট করা
        $request_data_json = json_encode($paymentData);

        // bKash এ পেমেন্ট রিকোয়েস্ট পাঠানো
        $response = BkashPaymentTokenize::cPayment($request_data_json);
        // $response = BkashPaymentTokenize::cPayment($request_data_json, 1); // মাল্টি-অ্যাকাউন্ট সেটআপের জন্য

        // পেমেন্ট ID এবং অ্যাকাউন্ট নম্বর স্টোর করা
        if (isset($response['bkashURL'])) {
            return redirect()->away($response['bkashURL']);
        } else {
            return redirect()->back()->with('error-alert2', $response['statusMessage']);
        }
    }

    public function callBack(Request $request)
    {
        if ($request->status == 'success') {
            $response = BkashPaymentTokenize::executePayment($request->paymentID);

            if (!$response) {
                $response = BkashPaymentTokenize::queryPayment($request->paymentID);
            }

            if (isset($response['statusCode']) && $response['statusCode'] == "0000" && $response['transactionStatus'] == "Completed") {
                $amount = $response['amount'];
                $userId = auth()->id();
                $transactionId = $response['trxID'];

                // অ্যাডমিন সেটিংস থেকে conversion_rate ফেচ করা
                $bkashSettings = BkashSetting::first();
                $conversionRate = $bkashSettings->conversion_rate ?? 0.01;

                // ডিপোজিট অ্যাডজাস্টমেন্ট করা
                $depositAmount = $amount * $conversionRate;

                // ডাটাবেজে ডিপোজিট ডিটেইলস সেভ করা
                \App\Models\Deposit::create([
                    'user_id' => $userId,
                    'account_id' => 1, // প্রকৃত account_id দিয়ে প্রতিস্থাপন করুন
                    'amount' => $depositAmount,
                    'transaction_id' => $transactionId,
                    'approval' => 1,
                ]);

                // ইউজারের ডিপোজিট ব্যালেন্স আপডেট করা
                $user = \App\Models\User::find($userId);
                $user->deposit_balance += $depositAmount;
                $user->save();

                return BkashPaymentTokenize::success('Thank you for your payment', $transactionId);
            }
            return BkashPaymentTokenize::failure($response['statusMessage']);
        } else if ($request->status == 'cancel') {
            return BkashPaymentTokenize::cancel('Your payment is canceled');
        } else {
            return BkashPaymentTokenize::failure('Your transaction is failed');
        }
    }

    public function searchTnx($trxID)
    {
        //response
        return BkashPaymentTokenize::searchTransaction($trxID);
        //return BkashPaymentTokenize::searchTransaction($trxID, 1); // মাল্টি-অ্যাকাউন্ট সেটআপের জন্য
    }

    public function refund(Request $request)
    {
        $paymentID = 'Your payment id';
        $trxID = 'your transaction no';
        $amount = 5;
        $reason = 'this is test reason';
        $sku = 'abc';
        //response
        return BkashRefundTokenize::refund($paymentID, $trxID, $amount, $reason, $sku);
        //return BkashRefundTokenize::refund($paymentID, $trxID, $amount, $reason, $sku, 1); // মাল্টি-অ্যাকাউন্ট সেটআপের জন্য
    }

    public function refundStatus(Request $request)
    {
        $paymentID = 'Your payment id';
        $trxID = 'your transaction no';
        return BkashRefundTokenize::refundStatus($paymentID, $trxID);
        //return BkashRefundTokenize::refundStatus($paymentID, $trxID, 1); // মাল্টি-অ্যাকাউন্ট সেটআপের জন্য
    }
}
