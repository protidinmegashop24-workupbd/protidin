<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SurveySubmission;
use App\Models\Wallet;
use App\Models\WalletTransaction;
use Illuminate\Support\Facades\DB;

class AdminApprovalController extends Controller
{
    public function index()
    {
        $subs = SurveySubmission::with('user', 'survey')
            ->where('verify_status', 'pending')
            ->latest()
            ->paginate(50);

        return view('admin.approvals.index', compact('subs'));
    }

    public function approve($id)
    {
        DB::transaction(function () use ($id) {
            $sub = SurveySubmission::lockForUpdate()->with('survey')->findOrFail($id);
            if ($sub->verify_status !== 'pending') return;

            $amount = (float)$sub->survey->reward;

            $wallet = Wallet::firstOrCreate(['user_id' => $sub->user_id], ['balance' => 0]);
            $wallet->update(['balance' => $wallet->balance + $amount]);

            WalletTransaction::create([
                'user_id' => $sub->user_id,
                'amount' => $amount,
                'type' => 'survey_reward',
                'reference' => $sub->unique_code,
                'note' => 'Survey reward approved',
            ]);

            $sub->update(['verify_status' => 'approved']);
        });

        return back()->with('success', 'Approved & wallet added');
    }

    public function reject($id)
    {
        $sub = SurveySubmission::findOrFail($id);
        if ($sub->verify_status === 'pending') {
            $sub->update(['verify_status' => 'rejected']);
        }
        return back()->with('success', 'Rejected');
    }
}
