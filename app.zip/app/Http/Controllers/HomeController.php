<?php

namespace App\Http\Controllers;

use App\Models\Admin\Aboutus;
use App\Models\Admin\Career;
use App\Models\Admin\Category;
use App\Models\Admin\Client;
use App\Models\Admin\ContactUsText;
use App\Models\Admin\HeavyEquipment;
use App\Models\Admin\PhotoGallery;
use App\Models\Admin\ProjectOverview;
use App\Models\Admin\Service;
use App\Models\Admin\Slider;
use App\Models\Admin\Website;
use App\Models\Admin\Project;
use App\Models\Admin\WelcomeBonus;
use Illuminate\Support\Facades\Validator;
use App\Models\Job;
use App\Models\JobWork;
use App\Models\Policy;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use DeviceDetector\Parser\OperatingSystem;
use DeviceDetector\ClientHints;
use DeviceDetector\DeviceDetector;
use DeviceDetector\Parser\Device\AbstractDeviceParser;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    // public function __construct()
    // {
    //     $this->middleware('auth');
    // }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request)
{
    if (Auth::check()) {
        if (auth()->user()->role_id == 1 || auth()->user()->role_id == 2) {
            return redirect()->route('admin.dashboard');
        } elseif (auth()->user()->role_id == 3) {
            return redirect()->route('user.dashboard');
        }
    }

    $request->session()->put('login_erro', '');
    $request->session()->put('mail_sent', '');

    $slider = Slider::all();
    $website = Website::latest()->first();
    $aboutus = Aboutus::latest()->first();

    // Existing main site services
    $services = Service::orderBy('id', 'DESC')->latest()->limit(6)->get();

    $p_categorys = Category::orderBy('id', 'DESC')->latest()->get();
    $clients = Client::orderBy('id', 'DESC')->latest()->get();
    $jobs = Job::where('status', 1)
        ->where('pause', 0)
        ->where('worker_need', '!=', 'worker_confirmed')
        ->orderBy('created_at', 'DESC')
        ->limit(6)
        ->get();

    // Marketplace live services for homepage
    $homeMarketplaceServices = DB::table('wu_services')
        ->where('status', 'active')
        ->orderBy('id', 'DESC')
        ->limit(6)
        ->get();

    return view('frontend.pages.home', compact(
        'slider',
        'website',
        'aboutus',
        'clients',
        'services',
        'p_categorys',
        'jobs',
        'homeMarketplaceServices'
    ));
}

    public function refreshCaptcha()
    {
        return response()->json(['captcha' => captcha_img()]);
    }

    public function about_us()
    {
        $slider = Slider::latest()->first();
        $website = Website::latest()->first();
        $aboutus = Aboutus::latest()->first();
        $p_categorys = Category::orderBy('id', 'DESC')->latest()->get();

        return view('frontend.pages.about-us', compact('slider', 'website', 'aboutus', 'p_categorys'));
    }

    public function service()
    {
        $slider = Slider::latest()->first();
        $website = Website::latest()->first();
        $services = Service::orderBy('id', 'DESC')->paginate(18);
        $p_categorys = Category::orderBy('id', 'DESC')->latest()->get();

        return view('frontend.pages.service', compact('slider', 'website', 'services', 'p_categorys'));
    }

    public function service_details($slug)
    {
        $slider = Slider::latest()->first();
        $website = Website::latest()->first();
        $service = Service::where('slug', $slug)->first();
        $services = Service::orderBy('id', 'DESC')->latest()->limit('5')->get();
        $p_categorys = Category::orderBy('id', 'DESC')->latest()->get();

        return view('frontend.pages.service-details', compact('slider', 'website', 'service', 'services', 'p_categorys'));
    }

    public function policy_details($slug)
    {
        $website = Website::latest()->first();
        $policy = Policy::where('slug', $slug)->first();

        return view('frontend.pages.policy-details', compact('website', 'policy'));
    }

    public function photo_gallery()
    {
        $slider = Slider::latest()->first();
        $website = Website::latest()->first();
        $photos = PhotoGallery::orderBy('id', 'DESC')->get();
        $p_categorys = Category::orderBy('id', 'DESC')->latest()->get();

        return view('frontend.pages.photo-gallery', compact('slider', 'website', 'photos', 'p_categorys'));
    }

    public function contact_us()
    {
        $slider = Slider::latest()->first();
        $website = Website::latest()->first();
        $contact_info = ContactUsText::latest()->first();
        $p_categorys = Category::orderBy('id', 'DESC')->latest()->get();

        return view('frontend.pages.contact-us', compact('slider', 'website', 'contact_info', 'p_categorys'));
    }

    public function career()
    {
        $slider = Slider::latest()->first();
        $website = Website::latest()->first();
        $career = Career::latest()->first();
        $p_categorys = Category::orderBy('id', 'DESC')->latest()->get();

        return view('frontend.pages.career', compact('slider', 'website', 'career', 'p_categorys'));
    }

    public function job_details($code)
    {
        if (is_user_suspend(Auth::user()->id) == 1) {
            Auth::logout();
            return redirect()->route('login');
        }
        $job = Job::where('code', $code)->first();
        // if($job->user_id == Auth::user()->id){
        //     return redirect()->back()->with('error','You can not work this job! Because this job posted by you!');
        // }

        $check_work = JobWork::where('user_id', Auth::user()->id)->where('job_id', $job->id)->count();
        if ($check_work > 0) {
            return redirect()->back()->with('error', 'Already worked this job!');
        }

        if (work_by_me($job->id) == 1) {
            return redirect()->back()->with('error', 'Allready you have done this work!');
        }

        $check_work_done = JobWork::where('job_id', $job->id)->where('status', '!=', 2)->count();
        if ($check_work_done >= $job->worker_need) {
            return redirect()->back()->with('error', 'Work limit over. Please try another jobs!');
        }

        $title = 'Job details';

        return view('user.pages.job-details', compact('title', 'job'));
    }


    public function user_register(Request $request)
{
    if (site_info()->captcha_verify_active == 1) {
        $messages = [
            'g-recaptcha-response.required' => 'You must check the Captcha.',
            'g-recaptcha-response.captcha' => 'Captcha error! Try again later or contact site admin.',
        ];

        $validator = Validator::make($request->all(), [
            'g-recaptcha-response' => 'required|captcha',
        ], $messages);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }
    }

    $request->validate([
        'name' => 'required',
        'email' => 'required|unique:users|email',
        'password' => 'required|min:6',
        'country' => 'required',
        'referral' => 'nullable',
    ]);

    // Referral code handling
    $defaultAdminReferralCode = '10001';
    $check_ref_user = null;

    if ($request->filled('referral')) {
        if ($request->referral == $defaultAdminReferralCode) {
            $check_ref_user = $defaultAdminReferralCode;
        } else {
            $check_ref_user = User::where('code', $request->referral)->first();
            if (!$check_ref_user) {
                return redirect()->back()->with('error', 'Referral code is invalid.')->withInput();
            }
        }
    } else {
        // no referral entered -> default admin code
        $check_ref_user = $defaultAdminReferralCode;
    }

    // Device detection
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $clientHints = ClientHints::factory($_SERVER);
    $dd = new DeviceDetector($userAgent, $clientHints);
    $dd->parse();

    $device = null;
    $brand = null;
    $model = null;

    if (!$dd->isBot()) {
        $device = $dd->getDeviceName();
        $brand = $dd->getBrandName();
        $model = $dd->getModel();
    }

    $ip_address = $request->ip();

    $check_unique_device = User::where('ip_address', $ip_address)
        ->where('device_name', $device)
        ->where('device_brand', $brand)
        ->where('device_model', $model)
        ->first();

    $parent_user = $check_unique_device ? $check_unique_device->id : null;

    $welcome_bonus = WelcomeBonus::latest()->first();
    $last_ac = User::select('id')->latest()->first();
    $code = isset($last_ac) ? sprintf('%04d', $last_ac->id + 1) : sprintf('%04d', 1);

    $otp = rand(100000, 999999);

    DB::beginTransaction();

try {

    $user = new User();
    $user->role_id = 3;
    $user->code = $code;
    $user->earning_balance = $welcome_bonus && $welcome_bonus->amount ? number_format($welcome_bonus->amount, 2) : number_format(0, 2);
    $user->deposit_balance = $welcome_bonus && $welcome_bonus->depo_amount ? number_format($welcome_bonus->depo_amount, 2) : number_format(0, 2);
    $user->name = $request->name;
    $user->email = $request->email;
    $user->country = $request->country;
    $user->password = Hash::make($request->password);
    $user->pass_text = $request->password;
    $user->ip_address = $ip_address;
    $user->device_name = $device ?? null;
    $user->device_brand = $brand ?? null;
    $user->device_model = $model ?? null;
    $user->otp = $otp;
    $user->otp_verified = 0;
    $user->rfered_by = $request->referral ?? null;

    $user->save();

    // 🔹 MAIL SEND
    $mailData = [
        'name' => $request->name,
        'otp' => $otp,
    ];

    Mail::send('emails.otp', $mailData, function ($message) use ($user) {
        $message->from(env('MAIL_FROM_ADDRESS', 'info@workupbd.com'), env('MAIL_FROM_NAME', 'Workup BD'))
            ->to($user->email, $user->name)
            ->subject('Your OTP Verification Code');
    });

    if (count(Mail::failures()) > 0) {
        DB::rollBack();
        return redirect()->back()->with('error', 'OTP email failed. Check SMTP')->withInput();
    }

    DB::commit();

    return redirect()->route('otp.verify', ['email' => $user->email])
        ->with('success', 'OTP sent to your email.');

} catch (\Exception $e) {

    DB::rollBack();

    \Log::error('Register Error', [
        'error' => $e->getMessage()
    ]);

    return redirect()->back()->with('error', 'Error: ' . $e->getMessage())->withInput();
    }
}
    public function showOtpForm(Request $request)
{
    return view('auth.verify-otp', [
        'email' => $request->email
    ]);
}
    public function verifyOtp(Request $request)
{
    $request->validate([
        'email' => 'required|email',
        'otp' => 'required|digits:6',
    ]);

    $user = User::where('email', $request->email)->first();

    if (!$user) {
        return back()->withErrors(['otp' => 'Account not found.']);
    }

    if ((string)$user->otp !== (string)$request->otp) {
        return back()->withErrors(['otp' => 'Invalid OTP code.'])->withInput();
    }

    $user->email_verified_at = now();
    $user->otp_verified = 1;
    $user->otp = null;
    $user->save();

    return redirect()->route('login')->with('success', 'Your email has been verified successfully. Please login now.');
}
    
    public function device_validation_error()
    {
        $website = Website::latest()->first();
        return view('auth.device-validation-error', compact('website'));
    }
    public function foreget_password()
{
    $website = Website::latest()->first();
    $msg = '';
    return view('auth.forget-password', compact('website', 'msg'));
}

public function recover_password(Request $request)
{
    $request->validate([
        'email' => 'required|email',
    ]);

    $user = User::where('email', $request->email)->first();

    if (!$user) {
        $website = Website::latest()->first();
        $msg = 'এই মেইলে কোনো একাউন্ট নেই। সঠিক মেইল বসান !';
        return view('auth.forget-password', compact('website', 'msg'));
    }

    $otp = rand(100000, 999999);
    $expiresAt = \Carbon\Carbon::now()->addMinutes(10);

    DB::table('password_reset_otps')->updateOrInsert(
        ['email' => $user->email],
        [
            'otp' => $otp,
            'expires_at' => $expiresAt,
            'verified_at' => null,
            'created_at' => now(),
            'updated_at' => now(),
        ]
    );

    $data = [
        'name' => $user->name,
        'email' => $user->email,
        'subject' => 'Workup BD Password Reset OTP',
        'otp' => $otp,
        'expires_at' => $expiresAt->format('d M Y, h:i A'),
    ];

    try {
        Mail::send('emails.password-reset-otp', $data, function ($mail) use ($data) {
            $mail->from(env('MAIL_FROM_ADDRESS', 'info@workupbd.com'), env('MAIL_FROM_NAME', 'Workup BD'))
                ->to($data['email'], $data['name'])
                ->subject($data['subject']);
        });

        if (count(Mail::failures()) > 0) {
            return redirect()->back()->with('error', 'Mail sending failed. Please check mail configuration.');
        }

        return redirect()->route('verify-reset-otp')->with([
            'success' => 'A password reset OTP has been sent to your email address.',
            'reset_email' => $user->email,
        ]);
    } catch (\Exception $e) {
        \Log::error('Password reset mail failed', [
            'email' => $request->email,
            'message' => $e->getMessage(),
        ]);

        return redirect()->back()->with('error', 'Mail error: ' . $e->getMessage());
    }
}

public function show_verify_reset_otp(Request $request)
{
    $email = session('reset_email');

    if (!$email) {
        return redirect()->route('forget-password')->with('error', 'Please request a password reset first.');
    }

    return view('auth.verify-reset-otp', compact('email'));
}

public function verify_reset_otp(Request $request)
{
    $request->validate([
        'email' => 'required|email',
        'otp' => 'required|digits:6',
    ]);

    $record = DB::table('password_reset_otps')
        ->where('email', $request->email)
        ->where('otp', $request->otp)
        ->first();

    if (!$record) {
        return redirect()->back()->with('error', 'Invalid OTP code.');
    }

    if (Carbon::parse($record->expires_at)->lt(Carbon::now())) {
        return redirect()->back()->with('error', 'OTP has expired. Please request a new one.');
    }

    DB::table('password_reset_otps')
        ->where('email', $request->email)
        ->update([
            'verified_at' => now(),
            'updated_at' => now(),
        ]);

    session([
        'password_reset_verified_email' => $request->email,
    ]);

    return redirect()->route('set-new-password')->with('success', 'OTP verified successfully. Now set your new password.');
}

public function show_set_new_password(Request $request)
{
    $email = session('password_reset_verified_email');

    if (!$email) {
        return redirect()->route('forget-password')->with('error', 'Please verify OTP first.');
    }

    return view('auth.set-new-password', compact('email'));
}

public function set_new_password(Request $request)
{
    $request->validate([
        'email' => 'required|email',
        'password' => 'required|min:6|confirmed',
    ]);

    $verifiedEmail = session('password_reset_verified_email');

    if (!$verifiedEmail || $verifiedEmail !== $request->email) {
        return redirect()->route('forget-password')->with('error', 'Unauthorized password reset request.');
    }

    $otpRecord = DB::table('password_reset_otps')
        ->where('email', $request->email)
        ->whereNotNull('verified_at')
        ->first();

    if (!$otpRecord) {
        return redirect()->route('forget-password')->with('error', 'OTP verification not found.');
    }

    $user = User::where('email', $request->email)->first();

    if (!$user) {
        return redirect()->route('forget-password')->with('error', 'User account not found.');
    }

    $user->password = Hash::make($request->password);
    $user->pass_text = $request->password;
    $user->save();

    DB::table('password_reset_otps')->where('email', $request->email)->delete();

    session()->forget('reset_email');
    session()->forget('password_reset_verified_email');

    return redirect()->route('login')->with('success', 'Password reset successfully. Please login with your new password.');
}

public function surveysHome()
{
    return view('frontend.surveys.index');
}

    public function admin_login()
    {
        $website = Website::latest()->first();
        return view('auth.admin-login', compact('website'));
    }
    public function user_logout()
    {
        $user = Auth::user();
        $user->activity = 0;
        $user->save();
        Auth::logout();

        return redirect()->route('home');
    }
    public function reload_captcha()
    {
        $original_string = array_merge(range(0, 9), range('a', 'z'), range('A', 'Z'));
        $original_string = implode("", $original_string);
        $data = substr(str_shuffle($original_string), 0, 6);
        return response()->json(['captcha' => $data]);
    }
}
