<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Admin\Role;
use Illuminate\Http\Request;
use App\Models\Admin\Website;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\Job;
use App\Models\JobReport;
use App\Models\JobWork;
use App\Models\ptc_job;
use App\Models\ptc_earn_history;
use App\Models\Admin\UserMessage;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;


class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $website = Website::latest()->first();
        $users = User::where('role_id', 3)->latest()->paginate(15);
        $roles = Role::all()->where('id', '!=', '3');
        $jobs = Job::all();
        $JobWork = JobWork::all();
        $ptc_job = ptc_job::all();
        $ptc_earn_history = ptc_earn_history::all();

        return view('backend.pages.usermanage.user', compact('users', 'roles', 'website','jobs','JobWork','ptc_job','ptc_earn_history'));
    }
    
    public function duplicate_users()
    {
        $website = Website::latest()->first();
        $users = User::where('role_id', 3)->where('is_new_device', 0)->latest()->paginate(15);
        $roles = Role::all()->where('id', '!=', '3');

        return view('backend.pages.usermanage.duplicate-user', compact('users', 'roles', 'website'));
    }
    
    public function user_search(Request $request)
    {
        $website = Website::latest()->first();
        $query = User::query();
        if ($request->search_data) {
            $query = $query->where('code', 'like', "%{$request->search_data}%");
            $query = $query->orWhere('name', 'like', "%{$request->search_data}%");
            $query = $query->orWhere('email', 'like', "%{$request->search_data}%");
        }
        $users = $query->where('role_id', 3)->latest()->paginate(15);
        $roles = Role::all()->where('id', '!=', '3');
        
        $jobs = Job::all();
        $JobWork = JobWork::all();
        $ptc_job = ptc_job::all();
        $ptc_earn_history = ptc_earn_history::all();
        
        return view('backend.pages.usermanage.user', compact('users', 'roles', 'website', 'jobs', 'JobWork', 'ptc_job', 'ptc_earn_history'));
    }
    public function user_full_job_view($id , string $viewType){
        // dd($id , $viewType);
        $website = Website::latest()->first();
        $users = User::where('role_id', 3)->latest()->paginate(15);
        $datas = null;
        
        if($viewType == 'postedJob'){
            $pageType = 'postedJob';
            $datas = Job::where('user_id',$id)->where('status', 1)->whereColumn('worker_need', '>', 'worker_confirmed')->latest()->get();
        }elseif($viewType == 'appliedJob'){
            $pageType = 'appliedJob';
            $datas = JobWork::where('user_id',$id)->get();
        }elseif($viewType == 'ptcPostedJob'){
            $pageType = 'ptcPostedJob';
        }elseif($viewType == 'ptcEarnedJob'){
            $pageType = 'ptcEarnedJob';
        }else{
            $pageType = '';
        }
        // return "hello";
        return view('backend.pages.usermanage.user-full-job-view',compact('website','users','pageType','datas'));
    }
    public function kyc_verify_check()
    {
        $website = Website::latest()->first();
        $users = User::where('role_id', 3)->where('kyc_status','pending')->latest()->paginate(15);
        $roles = Role::all()->where('id', '!=', '3');
        return view('backend.pages.usermanage.kyc-requested', compact('users', 'roles', 'website'));
        return "Hello";
    }
    public function kyc_user_list()
    {
        $website = Website::latest()->first();
        $users = User::where('role_id', 3)->where('kyc_status','approve')->latest()->paginate(15);
        $roles = Role::all()->where('id', '!=', '3');
        return view('backend.pages.usermanage.kyc-user', compact('users', 'roles', 'website'));
    }
    public function kyc_user_unapprove(){
        $website = Website::latest()->first();
        $users = User::where('role_id', 3)->where('kyc_status','unapprove')->latest()->paginate(15);
        $roles = Role::all()->where('id', '!=', '3');
        return view('backend.pages.usermanage.kyc-unapprove', compact('users', 'roles', 'website'));
    }
    public function kyc_verify_check_update(Request $request){
        // dd($request);
        $findUser = User::where('id',$request->id)->first();
        if(!$findUser){
            return redirect()->back()->with('error','User Not Found Please try Again');
        }
        if($request->kyc_status){

            $findUser->kyc_status = $request->kyc_status;

            if($request->kyc_status == 'approve'){

                $findUser->is_verified = 1;

            }elseif($request->kyc_status == 'unapprove'){
                $findUser->is_verified = 0;
            }else{
                $findUser->is_verified = 0;
            }
        }
        if($request->kyc_notice){
            $findUser->kyc_notice = $request->kyc_notice;
        }        
        $status = $findUser->update();
        if($status){
            return redirect()->back()->with('success','User Has Info Updated');
        }else{
            return redirect()->back()->with('error','User Not Updated Please try Again');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'name' => 'required|min:3|max:50',
            'username' => 'required|min:3|max:50',
            'email' => 'required|unique:users',
            'phone' => 'required|unique:users',
            'role_id' => 'required',
            'password' => 'required',
        ]);

        $user = new User();
        $user->name = Str::ucfirst($request->input('name'));
        $user->username = $request->input('username');
        $user->email = $request->input('email');
        $user->role_id = $request->input('role_id');
        $user->status = '0';
        $user->password = Hash::make($request->input('password'));
        $user->phone = $request->input('phone');

        $image = $request->file('image');
        if ($image) {
            $image_name = Str::random(20);
            $ext = strtolower($image->getClientOriginalExtension());
            $image_full_name = $image_name.'.'.$ext;
            $upload_path = 'backend/img/user/';
            $image_url = $upload_path.$image_full_name;
            $image->move($upload_path, $image_full_name);
            $user->image = $image_url;
        }
        
        $user->save();
        return redirect()->back()->with('message','User added Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $website = Website::latest()->first();
        $user = DB::table('users')->where('id', $id)->first();
        $roles = Role::all()->where('id', '!=', '3');
        return view('backend.pages.usermanage.useredit', compact('user', 'website', 'roles'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function user_balance(Request $request, $id){
        $user = User::find($id);
        $user->deposit_balance = $request->deposit_balance;
        $user->earning_balance = $request->earning_balance;
        $user->save();

        return redirect()->back()->with('message','Data Updated Successfully!');
    }
    public function user_activity(Request $request, $id){
        $user = User::find($id);
        $user->status = $request->status;
        $user->reason = $request->reason;
        $user->save();
        
        $data = new UserMessage();
        $data->user_id = $id;
        $data->message_title = 'Activiti Notice';
        $data->message = $request->reason;
        $data->save();

        return redirect()->back()->with('message','Data Updated Successfully!');
    }
    public function user_suspend(Request $request, $id){
        $user = User::find($id);
        $user->is_suspended = $request->is_suspended;
        if($request->is_suspended == 1){
            $user->suspend_reason = $request->suspend_reason;
            $user->suspend_release = date("Y-m-d H:i:s", strtotime('+'.$request->suspend_release.' hours'));
        }else{
            $user->suspend_reason = NULL;
            $user->suspend_release = NULL;
        }
        $user->save();
        
        $data = new UserMessage();
        $data->user_id = $id;
        $data->message_title = 'Account Suspend';
        $data->message = $request->suspend_reason;
        $data->save();

        return redirect()->back()->with('message','Data Updated Successfully!');
    }
    public function user_ban(Request $request, $id){
        $user = User::find($id);
        $user->is_ban = $request->is_ban;
        if($request->is_ban == 1){
            $user->ban_reason = $request->ban_reason;
        }else{
            $user->ban_reason = NULL;
        }
        $user->save();
        
        $data = new UserMessage();
        $data->user_id = $id;
        $data->message_title = 'Account Ban';
        $data->message = $request->ban_reason;
        $data->save();

        return redirect()->back()->with('message','Data Updated Successfully!');
    }
    public function update(Request $request, $id)
    {
        
        
        
        
        
        
        
        
       $user = User::findOrFail($id);
    
    $user->name = $request->name;
    $user->email = $request->email;
    $user->deposit_balance = $request->deposit_balance;
    $user->earning_balance = $request->earning_balance;
   
    
    $user->save();

    return redirect()->back()->with('message', 'User information updated successfully.');



        
        
        
        
        
        
        
        
        $validatedData = $request->validate([
            'name' => 'required|min:3|max:50',
            'email' => 'required',
        ]);
        
        $user = User::find($id);
        $user->name = Str::ucfirst($request->input('name'));
        $user->username = $request->input('username');
        $user->email = $request->input('email');
        $user->role_id = $request->input('role_id');
        $user->phone = $request->input('phone');

        $image = $request->file('image');
        if ($image) {
            if(file_exists($user->image)){
                unlink($user->image);
            }
            $image_name = Str::random(20);
            $ext = strtolower($image->getClientOriginalExtension());
            $image_full_name = $image_name.'.'.$ext;
            $upload_path = 'backend/img/user/';
            $image_url = $upload_path.$image_full_name;
            $image->move($upload_path, $image_full_name);
            $user->image = $image_url;
        }
        
        $user->save();
        return redirect()->back()->with('message','User update Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user = User::find($id);
        if(file_exists($user->image)){
            unlink($user->image);
        }
        $user->delete();
        return redirect()->back()->with('message','User deleted Successfully!');
    }
    
    public function reactive_user_account($id)
    {
        $user = User::find($id);
        $user->is_suspended = 0;
        $user->is_ban = 0;
        $user->save();
        return redirect()->back()->with('message','User Successfully Reactive!');
    }
    
    
    
    
    
   public function updateEmailStatus(Request $request, $id)
{
    $user = User::findOrFail($id);

    // Update the email verification status based on the form input
    if ($request->input('is_verified') == 1) {
        $user->markEmailAsVerified();
    } else {
        $user->email_verified_at = null;
    }

    $user->save();

    return redirect()->back()->with('message', 'Email verification status updated successfully!');
}



    
    
    
    
    
    
    
    public function updateStatus(Request $request, $id)
{
    $user = User::findOrFail($id);
    
    
    $user->is_verified = $request->input('is_verified');
    $user->save();

    return redirect()->back()->with('message', 'User account status updated successfully!');
}

    
}
