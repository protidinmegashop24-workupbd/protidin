<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Admin\Website;
use App\Models\Job;
use App\Models\JobWork;
use App\Models\ptc_job;
use App\Models\ptc_job_history;
use App\Models\User;
use App\Models\Admin\Role;
use Illuminate\Http\Request;

class JobWorkController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $datas = JobWork::where('trash', 0)->latest()->get();
        $website = Website::latest()->first();
        $title = 'Worked Job List';

        return view('backend.pages.job-manage.job-work', compact('title', 'website', 'datas'));
    }
    
    public function reject_request()
    {
        $datas = JobWork::where('status', 5)->where('trash', 0)->latest()->get();
        $website = Website::latest()->first();
        $title = 'Worked Reject Request';

        return view('backend.pages.job-manage.job-work-reject-request', compact('title', 'website', 'datas'));
    }
    
    public function rejected_work()
    {
        $datas = JobWork::where('status', 2)->where('trash', 0)->latest()->get();
        $website = Website::latest()->first();
        $title = 'Worked Job Reject List';

        return view('backend.pages.job-manage.job-work-reject', compact('title', 'website', 'datas'));
    }
    
    public function job_work_final_reject($id)
    {
        $job_work = JobWork::find($id);
        $msg_user_id = $job_work->user_id;
        
        $job_work->status = 2;

        $job = Job::find($job_work->job_id);
        if($job){
            $reject_done = $job->reject_done + 1;
            $job->reject_done = $reject_done;
            $job->save();
        }

        $job_work->save();

        return redirect()->back()->with('message','Successfully rejected this job!');
    }

    public function job_work_approve($id)
    {
        $job_work = JobWork::find($id);

        $job = Job::find($job_work->job_id);

        $user = User::find($job_work->user_id);
        $user->earning_balance = $user->earning_balance + $job->each_worker_earn;

        $website = Website::latest()->first();
        if($website->referral_earning_commission > 0){
            $earning_commission = ($website->referral_earning_commission * $job->each_worker_earn) / 100;

            $refered_by = User::find($user->rfered_by);
            if($refered_by){
                $refered_by->earning_balance = $refered_by->earning_balance + $earning_commission;
                $refered_by->save();
                $user->earning_commision_from_refer = $user->earning_commision_from_refer + $earning_commission;
            }
        }

        $user->save();

        $job->worker_confirmed = $job->worker_confirmed + 1;

        $job_work->status = 1;
        $job_work->save();

        $job->save();

        return redirect()->back()->with('message','Successfully approved this job!');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $job = JobWork::find($id);
        $job->delete();

        return redirect()->back()->with('message','Successfully deleted this job!');
    }
    
    
    
    
    public function ptcRunningAdmin(){
        $website = Website::latest()->first();
        $jobs = ptc_job::where('ptc_status', 'running')->where('ptc_expire_day','>',now())->paginate(15);
        $roles = Role::all()->where('id', '!=', '3');
        return view('backend.pages.ptc-job.running-job',compact('jobs','website','roles'));
    }
    public function ptcExpiredAdmin(){
        $website = Website::latest()->first();
        $jobs = ptc_job::where('ptc_status','!=','done')->where('ptc_expire_day','<',now())->paginate(15);
        $roles = Role::all()->where('id', '!=', '3');
        return view('backend.pages.ptc-job.running-job',compact('jobs','website','roles'));
    }
    public function ptcAdminPending(){
        $website = Website::latest()->first();
        $jobs = ptc_job::where('ptc_status','adminPending')->where('ptc_expire_day','>',now())->paginate(15);
        $roles = Role::all()->where('id', '!=', '3');
        return view('backend.pages.ptc-job.running-job',compact('jobs','website','roles'));
    }
    public function ptcDeleteRequest(){
        $website = Website::latest()->first();
        $jobs = ptc_job::where('ptc_status','req_delete')->where('ptc_expire_day','>',now())->paginate(15);
        $roles = Role::all()->where('id', '!=', '3');
        return view('backend.pages.ptc-job.running-job',compact('jobs','website','roles'));
    }
    public function ptcDeleteList(){
        $website = Website::latest()->first();
        $jobs = ptc_job::where('ptc_status','deleted')->where('ptc_expire_day','>',now())->paginate(15);
        $roles = Role::all()->where('id', '!=', '3');
        return view('backend.pages.ptc-job.running-job',compact('jobs','website','roles'));
    }
    public function ptcRejectList(){
        $website = Website::latest()->first();
        $jobs = ptc_job::where('ptc_status','reject')->where('ptc_expire_day','>',now())->paginate(15);
        $roles = Role::all()->where('id', '!=', '3');
        return view('backend.pages.ptc-job.running-job',compact('jobs','website','roles'));
    }
    public function ptcJobHistoryAdmin(){
        $website = Website::latest()->first();
        $jobs = ptc_job::paginate(15);
        $roles = Role::all()->where('id', '!=', '3');
        return view('backend.pages.ptc-job.running-job',compact('jobs','website','roles'));
    }
    public function ptcRunningAdminStore(Request $request){
        $find = ptc_job::where('id',$request->id)->first();
        if($request->ptc_reject_notice){
            $find->ptc_reject_notice = $request->ptc_reject_notice;
        }
        $find->ptc_status = $request->ptc_status;
        $status = $find->update();
        if($status){
            return redirect()->back()->with('success','Successfully Change the Status');
        }else{
            return redirect()->back()->with('error','Something Went Wrong');
        }

    }
}
