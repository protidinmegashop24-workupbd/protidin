<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Admin\Role;
use App\Models\Admin\Website;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Admin\UserMessage;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;


class AdminController extends Controller
{
    /**
     * Display a listing of admin accounts.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $website = Website::latest()->first();
        $admins = User::whereIn('role_id', [1, 2])->latest()->paginate(15);
        $roles = Role::all()->where('id', '!=', '3');  // Exclude normal user roles
        
        return view('backend.pages.adminmanage.admin', compact('admins', 'roles', 'website'));
    }

    /**
     * Search for admin accounts.
     */
    public function admin_search(Request $request)
    {
        $website = Website::latest()->first();
        $query = User::query();
        if ($request->search_data) {
            $query = $query->where('code', 'like', "%{$request->search_data}%");
            $query = $query->orWhere('name', 'like', "%{$request->search_data}%");
            $query = $query->orWhere('email', 'like', "%{$request->search_data}%");
        }
        $admins = $query->whereIn('role_id', [1, 2])->latest()->paginate(15);
        $roles = Role::all()->where('id', '!=', '3');

        return view('backend.pages.adminmanage.admin', compact('admins', 'roles', 'website'));
    }

    /**
     * Show the form for creating a new admin account.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $website = Website::latest()->first();
        return view('backend.pages.adminmanage.admincreate', compact('website'));
    }

    /**
     * Store a newly created admin account in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        
        
        $validatedData = $request->validate([
            'name' => 'required|min:3|max:50',
            'email' => 'required|unique:users',
            'role_id' => 'required|in:1,2,3', // 1 = Main Admin, 2 = Sub Admin
            'password' => 'required',
        ]);

        $admin = new User();
        $admin->name = Str::ucfirst($request->input('name'));
        $admin->email = $request->input('email');
        $admin->role_id = $request->input('role_id');
        $admin->password = Hash::make($request->input('password'));
        
        $image = $request->file('image');
        if ($image) {
            $image_name = Str::random(20);
            $ext = strtolower($image->getClientOriginalExtension());
            $image_full_name = $image_name.'.'.$ext;
            $upload_path = 'backend/img/admin/';
            $image_url = $upload_path.$image_full_name;
            $image->move($upload_path, $image_full_name);
            $admin->image = $image_url;
        }

        $admin->save();
        return redirect()->back()->with('message','Admin added successfully');
    }

    /**
     * Show the form for editing the specified admin account.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
   // In AdminController.php

public function edit($id)
{
    $admin = User::findOrFail($id);
    $roles = Role::all();
    return view('backend.pages.adminmanage.adminedit', compact('admin', 'roles'));
}

public function update(Request $request, $id)
{
    $admin = User::findOrFail($id);

    $validatedData = $request->validate([
        'name' => 'required|min:3|max:50',
        'email' => 'required|email|unique:users,email,' . $id,
        'role_id' => 'required|in:1,2,3',  // Allow changing roles.
    ]);

    // Update fields
    $admin->name = $request->input('name');
    $admin->email = $request->input('email');
    $admin->role_id = $request->input('role_id');

    // Optional password change
    if ($request->filled('password')) {
        $admin->password = Hash::make($request->input('password'));
    }

    $admin->save();

    return redirect()->back()->with('message', 'Admin updated successfully');
}


    /**
     * Remove the specified admin account from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $admin = User::findOrFail($id);
        if (file_exists($admin->image)) {
            unlink($admin->image);
        }
        $admin->delete();
        return redirect()->back()->with('message','Admin deleted successfully');
    }

   

 
}
