<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Admin\Website;
use Illuminate\Http\Request;
use App\Models\BkashSetting;

class BkashPaymentController extends Controller
{
    /**
     * Display the bKash payment settings.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $settings = BkashSetting::first();
        $website = Website::latest()->first();
        $title = 'bKash Payment Settings'; // সংশোধিত টাইটেল
        return view('backend.pages.system-setting.bkash_payment_settings', compact('title', 'website', 'settings'));
    }

    /**
     * Update the bKash payment settings.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request)
    {
        $validatedData = $request->validate([
            'min_amount' => 'required|numeric|min:1',
             'description' => 'nullable|string',
             'status' => 'required|boolean',
            
        ]);

        $settings = BkashSetting::first();
        if ($settings) {
            $settings->update($validatedData);
        } else {
            BkashSetting::create($validatedData);
        }

        // সেশনে 'success' নামে মেসেজ সেট করা হয়েছে
        return redirect()->back()->with('message', 'bKash payment settings updated successfully.');
    }
}
