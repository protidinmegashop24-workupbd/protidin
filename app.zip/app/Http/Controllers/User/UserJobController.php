<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Admin\Category;
use App\Models\Admin\Continent;
use App\Models\Admin\Country;
use App\Models\Admin\JobFee;
use App\Models\Admin\LocationZone;
use App\Models\Admin\LocationZoneCountry;
use App\Models\Admin\MainWallet;
use App\Models\Admin\SubCategory;
use App\Models\Admin\Website;
use App\Models\BoostCharge;
use App\Models\BoostJob;
use App\Models\Job;
use App\Models\ptc_job;
use App\Models\ptc_earn_history;
use App\Models\JobCountry;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

class UserJobController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(is_user_suspend(Auth::user()->id) == 1){
            Auth::logout();
            return redirect()->route('login');
        }
        
        // if( Auth::user()->is_ban == 1 && suspend_url_status('job') == 1){
        $currenturl = url()->current();
        if( Auth::user()->is_ban == 1 && suspend_url_status($currenturl) == 1){
            return redirect()->route('user.account-suspended');
        }
        
        job_delete(Auth::user()->id);
        $datas = Job::where('user_id', Auth::user()->id)->where('status', '!=', 2)->latest()->paginate(25);
        $title = 'Job List';

        return view('user.pages.job-list', compact('title', 'datas'));
    }

    public function get_recent_job(Request $request)
{
    $last_id = '';
    $job_found = 0;

    $job_founds = Job::where('status', 1)
        ->where('completed_work', 0)
        ->where('pause', 0)
        ->orderBy('created_at', 'DESC')
        ->get();

    foreach ($job_founds as $job) {
        if (
            $job->worker_need > $job->worker_confirmed &&
            $job->worker_need > complete_work_this_job($job->id) &&
            work_by_me($job->id) == 0 &&
            this_job_for_me($job->id) == 1 &&
            boost_active($job->id) == 0
        ) {
            $job_found++;
        }
    }

    $jobs = Job::where('status', 1)
        ->orderBy('created_at', 'DESC')
        ->limit(20)
        ->get();

    $filteredJobs = collect();

    foreach ($jobs as $job) {
        if (
            $job->worker_need > $job->worker_confirmed &&
            $job->worker_need > complete_work_this_job($job->id) &&
            work_by_me($job->id) == 0 &&
            this_job_for_me($job->id) == 1 &&
            boost_active($job->id) == 0
        ) {
            $filteredJobs->push($job);
            $last_id = $job->id;
        }
    }

    $html = view('user.partials.find-job-items', ['jobs' => $filteredJobs])->render();

    return ['html' => $html, 'last_id' => $last_id, 'job_found' => $job_found];
}

public function get_heigh_cost_job(Request $request)
{
    $last_id = '';
    $job_found = 0;

    $job_founds = Job::where('status', 1)
        ->where('completed_work', 0)
        ->where('pause', 0)
        ->orderBy('budget', 'DESC')
        ->get();

    foreach ($job_founds as $job) {
        if (
            $job->worker_need > $job->worker_confirmed &&
            $job->worker_need > complete_work_this_job($job->id) &&
            work_by_me($job->id) == 0 &&
            this_job_for_me($job->id) == 1 &&
            boost_active($job->id) == 0
        ) {
            $job_found++;
        }
    }

    $jobs = Job::where('status', 1)
        ->orderBy('budget', 'DESC')
        ->limit(20)
        ->get();

    $filteredJobs = collect();

    foreach ($jobs as $job) {
        if (
            $job->worker_need > $job->worker_confirmed &&
            $job->worker_need > complete_work_this_job($job->id) &&
            work_by_me($job->id) == 0 &&
            this_job_for_me($job->id) == 1 &&
            boost_active($job->id) == 0
        ) {
            $filteredJobs->push($job);
            $last_id = $job->id;
        }
    }

    $html = view('user.partials.find-job-items', ['jobs' => $filteredJobs])->render();

    return ['html' => $html, 'last_id' => $last_id, 'job_found' => $job_found];
}

public function get_job_country_wise(Request $request)
{
    $country_id = $request->country_id;
    $last_id = '';
    $job_found = 0;

    $job_founds = Job::where('continent_id', $country_id)
        ->where('status', 1)
        ->where('completed_work', 0)
        ->where('pause', 0)
        ->get();

    foreach ($job_founds as $job) {
        if (
            $job->worker_need > $job->worker_confirmed &&
            $job->worker_need > complete_work_this_job($job->id) &&
            work_by_me($job->id) == 0 &&
            this_job_for_me($job->id) == 1 &&
            boost_active($job->id) == 0
        ) {
            $job_found++;
        }
    }

    $jobs = Job::where('continent_id', $country_id)
        ->where('status', 1)
        ->orderBy('created_at', 'DESC')
        ->limit(20)
        ->get();

    $filteredJobs = collect();

    foreach ($jobs as $job) {
        if (
            $job->worker_need > $job->worker_confirmed &&
            $job->worker_need > complete_work_this_job($job->id) &&
            work_by_me($job->id) == 0 &&
            this_job_for_me($job->id) == 1 &&
            boost_active($job->id) == 0
        ) {
            $filteredJobs->push($job);
            $last_id = $job->id;
        }
    }

    $html = view('user.partials.find-job-items', ['jobs' => $filteredJobs])->render();

    return ['html' => $html, 'last_id' => $last_id, 'job_found' => $job_found];
}

public function get_job_category_wise(Request $request)
{
    $category_id = $request->category_id;
    $last_id = '';
    $job_found = 0;

    $job_founds = Job::where('category_id', $category_id)
        ->where('status', 1)
        ->where('completed_work', 0)
        ->where('pause', 0)
        ->get();

    foreach ($job_founds as $job) {
        if (
            $job->worker_need > $job->worker_confirmed &&
            $job->worker_need > complete_work_this_job($job->id) &&
            work_by_me($job->id) == 0 &&
            this_job_for_me($job->id) == 1 &&
            boost_active($job->id) == 0
        ) {
            $job_found++;
        }
    }

    $jobs = Job::where('category_id', $category_id)
        ->where('status', 1)
        ->orderBy('created_at', 'DESC')
        ->limit(20)
        ->get();

    $filteredJobs = collect();

    foreach ($jobs as $job) {
        if (
            $job->worker_need > $job->worker_confirmed &&
            $job->worker_need > complete_work_this_job($job->id) &&
            work_by_me($job->id) == 0 &&
            this_job_for_me($job->id) == 1 &&
            boost_active($job->id) == 0
        ) {
            $filteredJobs->push($job);
            $last_id = $job->id;
        }
    }

    $html = view('user.partials.find-job-items', ['jobs' => $filteredJobs])->render();

    return ['html' => $html, 'last_id' => $last_id, 'job_found' => $job_found];
}

public function get_regular_job(Request $request)
{
    $jobs = Job::where('status', 1)
        ->where('pause', 0)
        ->where('completed_work', 0)
        ->latest()
        ->get();

    $filteredJobs = collect();

    foreach ($jobs as $job) {
        if (
            $job->worker_need > $job->worker_confirmed &&
            $job->worker_need > complete_work_this_job($job->id) &&
            work_by_me($job->id) == 0 &&
            this_job_for_me($job->id) == 1 &&
            boost_active($job->id) == 0
        ) {
            $filteredJobs->push($job);
        }
    }

    return view('user.partials.find-job-items', ['jobs' => $filteredJobs])->render();
}

public function get_load_more_job(Request $request)
{
    $last_id = $request->last_id;
    $filter_type = $request->filter_type;
    $category_id = $request->category_id;
    $country_id = $request->country_id;
    $new_last_id = '';

    if ($filter_type == 'category') {
        $jobs = Job::where('category_id', $category_id)
            ->where('id', '<', $last_id)
            ->where('status', 1)
            ->where('completed_work', 0)
            ->where('pause', 0)
            ->orderBy('created_at', 'DESC')
            ->limit(20)
            ->get();
    } elseif ($filter_type == 'country') {
        $jobs = Job::where('continent_id', $country_id)
            ->where('id', '<', $last_id)
            ->where('status', 1)
            ->where('completed_work', 0)
            ->where('pause', 0)
            ->orderBy('created_at', 'DESC')
            ->limit(20)
            ->get();
    } else {
        $jobs = Job::where('id', '<', $last_id)
            ->where('status', 1)
            ->where('completed_work', 0)
            ->where('pause', 0)
            ->orderBy('created_at', 'DESC')
            ->limit(20)
            ->get();
    }

    $filteredJobs = collect();

    foreach ($jobs as $job) {
        if (
            $job->worker_need > $job->worker_confirmed &&
            $job->worker_need > complete_work_this_job($job->id) &&
            work_by_me($job->id) == 0 &&
            this_job_for_me($job->id) == 1 &&
            boost_active($job->id) == 0
        ) {
            $filteredJobs->push($job);
            $new_last_id = $job->id;
        }
    }

    $html = view('user.partials.find-job-items', ['jobs' => $filteredJobs])->render();

    return ['html' => $html, 'last_id' => $new_last_id, 'job_found' => $filteredJobs->count()];
}
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(is_user_suspend(Auth::user()->id) == 1){
            Auth::logout();
            return redirect()->route('login');
        }
        
        // if( Auth::user()->is_ban == 1 && suspend_url_status('job-create') == 1){
        $currenturl = url()->current();
        if( Auth::user()->is_ban == 1 && suspend_url_status($currenturl) == 1){
            return redirect()->route('user.account-suspended');
        }
        
        $continents = Continent::orderBy('id', 'ASC')->get();
        $countrys = Country::orderBy('id', 'ASC')->get();
        $categorys = Category::orderBy('id', 'ASC')->get();
        $job_fee = JobFee::latest()->first();
        $title = 'Add new job';

        return view('user.pages.job-create', compact('continents', 'countrys', 'categorys', 'job_fee', 'title'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'continent' => 'required',
            'category_id' => 'required',
            'sub_category' => 'required',
            'specific_task' => 'required',
            'required_proof' => 'required',
            'worker_need' => 'required',
            'each_worker_earn' => 'required',
            'required_screenshots' => 'required',
            'estimited_day' => 'required',
            'budget' => 'required',
        ]);
        
        // return $request;

        $website = Website::latest()->first();

        $job_cost = $request->budget;
        if(Auth::user()->deposit_balance < $job_cost){
            return redirect()->back()->with('error','You have no sufficient balance for job.');
        }else{
            $user_balance = User::find(Auth::user()->id);
            $user_balance->deposit_balance = $user_balance->deposit_balance - $job_cost;
            $user_balance->save();

            $main_wallet = MainWallet::latest()->first();
            $main_wallet->amount = $main_wallet->amount + $job_cost;
            $main_wallet->save();
        }

        $last_ac = Job::select('id')->latest()->first();
        if (isset($last_ac)) {
            $code = sprintf('%04d', $last_ac->id + 1000001);
        } else {
            $code = sprintf('%04d', 1000001);
        }

        $job = new Job();
        $job->code = $code;
        $job->title = $request->title;
        $job->slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $request->title))).'-'.uniqid();
        $job->continent_id = $request->continent;
        $job->category_id = $request->category_id;
        $job->sub_category = $request->sub_category;
        $job->specific_task = trim(implode("|",$request->specific_task),"|");
        $job->required_proof = $request->required_proof;

        $image = $request->file('thumbnail');
        if ($image) {
            $image_name = Str::random(20);
            $ext = strtolower($image->getClientOriginalExtension());
            $image_full_name = $image_name.'.'.$ext;
            $upload_path = 'backend/img/job/';
            $image_url = $upload_path.$image_full_name;
            $success = $image->move($upload_path, $image_full_name);
            $job->thumbnail_image = $image_url;
        }

        $max_reject = ceil(($request->worker_need * $website->job_work_reject_ratio) / 100);

        $job->worker_need = $request->worker_need;
        $job->max_reject = $max_reject;
        $job->each_worker_earn = $request->each_worker_earn;
        $job->required_screenshots = $request->required_screenshots;
        $job->estimited_day = $request->estimited_day;
        $job->budget = $request->budget;
        $job->user_id = Auth::user()->id;
        $job->save();
        
        $check_job = Job::where('code', $code)->first();
        if($check_job && $request->country_id){
            foreach($request->country_id as $country_id){
                $job_country = new JobCountry();
                $job_country->job_id = $check_job->id;
                $job_country->country_id = $country_id;
                $job_country->save();
            }
        }

        return redirect()->route('user.job-post-done')->with('message','Job added successfully');
    }
    
    public function job_post_done()
    {
        job_delete(Auth::user()->id);
        $datas = Job::where('user_id', Auth::user()->id)->where('status', '!=', 2)->latest()->paginate(25);
        $title = 'Job Post Done';

        return view('user.pages.job-post-done', compact('title', 'datas'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if(is_user_suspend(Auth::user()->id) == 1){
            Auth::logout();
            return redirect()->route('login');
        }
        
        $continents = Continent::orderBy('id', 'ASC')->get();
        $categorys = Category::orderBy('id', 'ASC')->get();
        $job = Job::find($id);
        $job_countrys = JobCountry::where('job_id', $id)->orderBy('id', 'ASC')->get();
        $job_sub_cats = SubCategory::where('category_id', $job->category_id)->orderBy('id', 'ASC')->get();
        $job_fee = JobFee::latest()->first();
        $title = 'Update job';

        return view('user.pages.job-edit', compact('continents', 'job_countrys', 'job', 'job_fee', 'categorys', 'job_sub_cats', 'title'));
    }

    public function job_work_need_update(Request $request, $id)
    {
        $request->validate([
            'worker' => 'required',
        ]);

        $job_fee = JobFee::latest()->first();
        $job = Job::find($id);

        $total_cost = $job->each_worker_earn * $request->worker;

        if(Auth::user()->deposit_balance < $total_cost){
            return redirect()->back()->with('error','You have no sufficient balance for job.');
        }else{
            $user_balance = User::find(Auth::user()->id);
            $user_balance->deposit_balance = $user_balance->deposit_balance - $total_cost;
            $user_balance->save();
        }

        $job->worker_need = $job->worker_need + $request->worker;
        if($request->estimited_day){
            $job->estimited_day = $job->estimited_day + $request->estimited_day;
        }
        $job->budget = $job->budget + $total_cost;
        $job->save();

        return redirect()->back()->with('message','Job worker updated successfully');
    }

    public function job_boosting_update(Request $request, $id)
    {
        $request->validate([
            'boost_charge' => 'required',
        ]);

        $boost_charge = BoostCharge::find($request->boost_charge);
        $charge = $boost_charge->charge;
        $job = Job::find($id);
        
        if($job->status == 0){
            return redirect()->back()->with('error','This job is not approved yet. After approve you can boost it!');
        }elseif($job->pause == 1){
            return redirect()->back()->with('error','This job is pause mode. After resume you can boost it!');
        }

        if(Auth::user()->deposit_balance < $charge){
            return redirect()->back()->with('error','You have no sufficient balance for job.');
        }else{
            $startTime = date("Y-m-d H:i:s");
            $expired_time = date('Y-m-d H:i:s', strtotime('+'.$boost_charge->duration .'minutes', strtotime($startTime)));
        
            $ck_exist = BoostJob::where('job_id', $id)->first();
            if($ck_exist){
                $boost_job = BoostJob::find($ck_exist->id);
                $boost_job->start_time = $startTime;
                $boost_job->expired_time = $expired_time;
                $boost_job->save();
            }else{
                $boost_job = new BoostJob();
                $boost_job->job_id = $id;
                $boost_job->start_time = $startTime;
                $boost_job->expired_time = $expired_time;
                $boost_job->save();
            }
            
            $user_balance = User::find(Auth::user()->id);
            $user_balance->deposit_balance = $user_balance->deposit_balance - $charge;
            $user_balance->save();

            $main_wallet = MainWallet::latest()->first();
            $main_wallet->amount = $main_wallet->amount + $charge;
            $main_wallet->save();
        }

        return redirect()->back()->with('message','Successfully boost your job.');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'worker_need' => 'required',
            'estimited_day' => 'required',
            'budget' => 'required',
        ]);

        $job = Job::find($id);
        $job->worker_need = $request->worker_need;
        $job->estimited_day = $request->estimited_day;
        
        $new_budget = number_format($request->budget, 5, ".", "") - number_format($job->budget, 5, ".", "");
        if(Auth::user()->deposit_balance < $new_budget){
            return redirect()->back()->with('error','You have no sufficient balance for job.');
        }else{
            $user_balance = User::find(Auth::user()->id);
            $user_balance->deposit_balance = $user_balance->deposit_balance - number_format($new_budget, 5, ".", "");
            $user_balance->save();

            $main_wallet = MainWallet::latest()->first();
            $main_wallet->amount = $main_wallet->amount + $new_budget;
            $main_wallet->save();
        }
        
        $job->budget = $request->budget + $new_budget;
        $job->created_at = date('Y-m-d G:i:s');
        $job->save();

        return redirect()->back()->with('message','Job updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function pause_job($id)
    {
        if( Auth::user()->is_ban == 1){
            return redirect()->route('user.account-suspended');
        }
        
        $job = Job::find($id);
        $updated_at = $job->updated_at;
        $job->pause = 1;
        $job->updated_at = $updated_at;
        $job->save();

        return redirect()->back()->with('message','Job Paused successfully');
    }
    
    public function start_job($id)
    {
        if( Auth::user()->is_ban == 1){
            return redirect()->route('user.account-suspended');
        }
        
        $job = Job::find($id);
        $updated_at = $job->updated_at;
        $job->pause = 0;
        $job->updated_at = $updated_at;
        $job->save();

        return redirect()->back()->with('message','Job Started successfully');
    }
    
    public function destroy($id)
    {
        $amount = 0;
        $job = Job::find($id);
        
        if(totle_pending_work_for_job($id) > 0){
            return redirect()->route('user.job-pending-working-proves', $job->code)->with('error','You have more pending worked list');
        }
        
        $job->delete_request = 1;
        
        // $remain_work = $job->worker_need - complete_work_this_job($job->id);
        // $amount = $remain_work * $job->each_worker_earn;
        
        // $user = User::find(Auth::user()->id);
        // $user->deposit_balance = $user->deposit_balance + number_format($amount, 5, ".", "");
        // $user->save();
        
        $job->save();
        // $job->delete();

        return redirect()->route('user.job')->with('message','Job delete request successfully submited.');
    }
    // TODO: PTC Job 
    public function ptcAdd(){
        return view('user.pages.ptc-job-create');
    }
    public function ptcAddStore(Request $request){
        if(is_user_suspend(Auth::user()->id) == 1){
            Auth::logout();
            return redirect()->route('login');
        }
        $currenturl = url()->current();
        if( Auth::user()->is_ban == 1 && suspend_url_status($currenturl) == 1){
            return redirect()->route('user.account-suspended');
        }

        // dd($request);
        $request->validate([
            'ptc_title' => 'required',
            'ptc_jobLink' => 'required',
            'package_name' => 'required',
            'ptc_worker_needed' => 'required',
            'ptc_expire_day' => 'required'
        ], [
            'ptc_title.required' => 'Should not be Empty',
            'ptc_jobLink.required' => 'Should not be Empty',
            'package_name.required' => 'Should not be Empty',
            'ptc_worker_needed.required' => 'Should not be Empty',
            'ptc_expire_day.required' => 'Should not be Empty',
        ]);
        if($request->package_name == '1'){
            $ptc_each_earn = 0.00020;
            $ptc_wait_time = 0;
        }elseif($request->package_name == '2'){
            $ptc_each_earn = 0.00025;
            $ptc_wait_time = 3;

        }elseif($request->package_name == '3'){
            $ptc_each_earn = 0.00035;
            $ptc_wait_time = 5;

        }elseif($request->package_name == '4'){
            $ptc_each_earn = 0.0005;
            $ptc_wait_time = 10;
            
        }elseif($request->package_name == '5'){
            $ptc_each_earn = 0.0007;
            $ptc_wait_time = 15;
            
        }elseif($request->package_name == '6'){
            $ptc_each_earn = 0.00085;
            $ptc_wait_time = 20;
            
        }elseif($request->package_name == '7'){
            $ptc_each_earn = 0.001;
            $ptc_wait_time = 30;
            
        }else{
            return redirect()->back()->with('error','Please Select a valide Package');
        }
        $job_cost = $ptc_each_earn * $request->ptc_worker_needed;
        $job_cost += $job_cost * 0.03;
        if(Auth::user()->deposit_balance < $job_cost){
            return redirect()->back()->with('error','You Do not have sufficient balance');
        }else{
            $findhim = User::where('id',Auth::user()->id)->first();
            $cBalance = $findhim->deposit_balance - $job_cost;
            $findhim->deposit_balance = $cBalance;
            $findhim->update();
        }
        $add = new ptc_job;
        $add->ptc_title = $request->ptc_title;
        $add->ptc_slug = Str::slug($request->ptc_title);
        $add->ptc_post_user_id = Auth::user()->id;
        $add->ptc_jobLink = $request->ptc_jobLink;
        $add->ptc_job_details = $request->ptc_job_details;        
        $add->ptc_clicked = 0;
        $add->ptc_worker_needed = $request->ptc_worker_needed;
        $add->ptc_each_earn = $ptc_each_earn;
        $add->ptc_wait_time = $ptc_wait_time;
        $add->ptc_expire_day = $request->ptc_expire_day;
        $add->ptc_expire_day = $request->ptc_expire_day;
        $add->ptc_status = 'running';
        $status = $add->save();
        if($status){
            return redirect()->back()->with('success','You have Successfully Add a PTC Job');
        }else{
            return redirect()->back()->with('error','Something Went Wrong, Try Again');
        }


    }
    public function ptcEdit($id){
        $job = ptc_job::where('id',$id)->first();
        if(!$job){
            return redirect()->route('user.ptcList')->with('error','Job Does Not Found in the list');
        }
        if($job->ptc_post_user_id != Auth::user()->id){
            return redirect()->route('user.ptcList')->with('error','You Do not have permission to change the Job Info');
        }
        return view('user.pages.ptc-job-edit',compact('job'));
    }
    public function ptcEditStore(Request $request){
        $job = ptc_job::where('id',$request->id)->first();
        if(!$job){
            return redirect()->route('user.ptcList')->with('error','Job Does Not Found in the list');
        }
        if($job->ptc_post_user_id != Auth::user()->id){
            return redirect()->route('user.ptcList')->with('error','You Do not have permission to change the Job Info');
        }
        $job->ptc_title = $request->ptc_title;
        $job->ptc_jobLink =  $request->ptc_jobLink;
        $job->ptc_status =  $request->ptc_status;
        $job->ptc_expire_day =  $request->ptc_expire_day;
        $job->ptc_jobLink =  $request->ptc_jobLink;
        $status = $job->update();
        if($status){
            return redirect()->route('user.myPostedJobHistory')->with('success','Successfully Updated The Job');
        }else{
            return redirect()->back()->with('error','Sorry, There is something wrong, Try Again');
        }
        
    }
    public function ptcList(){
        $userId = Auth::user()->id;
            // Retrieve jobs that the user collected today
        $completedJobToday = ptc_earn_history::where('ptc_worker_id', $userId)
            ->whereDate('ptc_collect_date', now()) // Check jobs collected today
            ->pluck('ptc_job_id')
            ->toArray();
            // Retrieve all jobs except the ones collected today
        $jobs = ptc_job::where('ptc_post_user_id', '!=', $userId)
            ->where('ptc_status', 'running')
            ->where('ptc_expire_day', '>', now())
            ->whereNotIn('id', $completedJobToday) // Exclude jobs collected today
            // ->whereColumn('ptc_clicked', '<', 'ptc_worker_needed')
            ->get();
            // dd($jobs);
        return view('user.pages.ptc-job-list',compact('jobs'));
    }
    public function ptcEarned(){
        $userId = Auth::user()->id;
        $historys = ptc_earn_history::where('ptc_worker_id',$userId)->get();
        return view('user.pages.ptc-earn-history',compact('historys'));
    }
    public function myRunning(){
        $userId = Auth::user()->id;
        $jobs = ptc_job::where('ptc_post_user_id',Auth::user()->id)->where('ptc_status', 'running')->where('ptc_expire_day','>',now())->get();
        return  view('user.pages.ptc-my-running-job',compact('jobs'));
    }
    public function myPostedJobHistory(){
        $jobs = ptc_job::where('ptc_post_user_id',Auth::user()->id)->where(function($query){
            $query->where('ptc_status','!=', 'running')->orWhere('ptc_expire_day','<',now());
        })->get();
        return view('user.pages.ptc-my-job-history',compact('jobs'));
    }    
    public function jobSeeker(Request $request){
        $id = $request->id;
        $job = ptc_job::where('id',$id)->first();
        if($job->ptc_worker_needed > $job->ptc_clicked){
            $earn = $job->ptc_each_earn;
            $addHistory = new ptc_earn_history;
            $addHistory->ptc_worker_id = Auth::user()->id;
            $addHistory->ptc_tk = $earn;
            $addHistory->ptc_job_id = $id;
            $addHistory->ptc_collect_date = now();
            $addHistory->save();
            $job->ptc_clicked = $job->ptc_clicked + 1;
            $job->update();
            $add = User::where('id',Auth::user()->id)->first();
            $add->earning_balance = $add->earning_balance + $earn;
            $add->update();
            $jobStatus = ptc_job::where('id',$id)->first();
            if($jobStatus->ptc_worker_needed <= $jobStatus->ptc_clicked){
                $jobStatus->ptc_status = 'done';
                $jobStatus->update();
            }
            return response('Success, You got the Balance Successfully');
        }
        // If Balance Not Transfer then check the problem and submit 
        $jobStatus = ptc_job::where('id',$id)->first();
        if($jobStatus->ptc_worker_needed <= $jobStatus->ptc_clicked){
            $jobStatus->ptc_status = 'done';
            $jobStatus->update();
        }
        return response('error, Job Finished, So Balance Not Transferd');
        // New Version Code 
        // $id = $request->id;
        // $user = Auth::user();
        
        // // Retrieve the job
        // $job = ptc_job::find($id);
        // if (!$job) {
        //     return response('error, Job Not Found', 404);
        // }
    
        // // Check if the job is already completed
        // if ($job->ptc_worker_needed <= $job->ptc_clicked) {
        //     if ($job->ptc_status !== 'done') {
        //         $job->ptc_status = 'done';
        //         $job->update();
        //     }
        //     return response('error, Job Finished, So Balance Not Transferred');
        // }
    
        // // Job is available, process earnings
        // $earn = $job->ptc_each_earn;
    
        // // Add earning history
        // ptc_earn_history::create([
        //     'ptc_worker_id' => $user->id,
        //     'ptc_tk' => $earn,
        //     'ptc_job_id' => $id,
        //     'ptc_collect_date' => now(),
        // ]);
    
        // // Increment job clicks safely
        // $job->increment('ptc_clicked');
    
        // // Update user balance
        // $user->increment('earning_balance', $earn);
    
        // // Check if job is now full
        // if ($job->ptc_worker_needed <= $job->ptc_clicked) {
        //     $job->update(['ptc_status' => 'done']);
        // }
    
        // return response('Success, You got the Balance Successfully');
    }
}
