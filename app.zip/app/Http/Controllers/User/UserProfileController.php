<?php

namespace App\Http\Controllers\User;
use App\Http\Controllers\Controller;
use App\Models\Admin\Country;
use App\Models\User;
use App\Models\Admin\UserDailySpin;
use App\Models\Admin\SpinSetting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;


class UserProfileController extends Controller
{
    public function index()
    {
        if (is_user_suspend(Auth::user()->id) == 1) {
            Auth::logout();
            return redirect()->route('login');
        }

        return view('user.pages.profile');
    }

    public function user_profile($id)
{
    $user = User::find($id);

    if (!$user) {
        abort(404);
    }

    $services = DB::table('wu_services')
        ->where('user_id', $id)
        ->where('status', 'active')
        ->latest()
        ->get();

    return view('user.pages.user-profile', compact('user', 'services'));
}

    public function add_spin_mark_to_earning(Request $request)
{
    $user = User::find(Auth::user()->id);

    $spinSetting = SpinSetting::latest()->first();
    $dailyLimit = $spinSetting ? (int) $spinSetting->daily_spin : 0;

    $todaySpin = UserDailySpin::where('user_id', $user->id)
        ->whereDate('created_at', now()->toDateString())
        ->count();

    if ($dailyLimit <= 0) {
        return response()->json([
            'status' => 'disabled',
            'message' => 'Spin is currently disabled.'
        ], 403);
    }

    if ($todaySpin >= $dailyLimit) {
        return response()->json([
            'status' => 'limit',
            'message' => 'Daily spin limit reached.'
        ], 403);
    }

    $mark = (float) $request->mark;

    DB::beginTransaction();

    try {
        $user->earning_balance = (float) $user->earning_balance + $mark;
        $user->save();

        $uspin = new UserDailySpin();
        $uspin->user_id = $user->id;
        $uspin->spin_amount = $mark;
        $uspin->created_at = now();
        $uspin->updated_at = now();
        $uspin->save();

        DB::commit();

        return response()->json([
            'status' => 'success',
            'message' => 'Reward added.',
            'today_spin' => $todaySpin + 1,
            'daily_limit' => $dailyLimit
        ]);
    } catch (\Exception $e) {
        DB::rollBack();

        return response()->json([
            'status' => 'error',
            'message' => $e->getMessage()
        ], 500);
    }
}

public function claim_share_bonus(Request $request)
{
    $user = User::find(Auth::user()->id);

    $todayClaim = DB::table('user_share_bonuses')
        ->where('user_id', $user->id)
        ->whereDate('created_at', now()->toDateString())
        ->count();

    if ($todayClaim > 0) {
        return response()->json([
            'status' => 'limit',
            'message' => 'You already claimed today share bonus.'
        ], 403);
    }

    $bonusAmount = 0.001; // চাইলে এখানে bonus amount change করবে

    DB::beginTransaction();

    try {
        $user->earning_balance = (float)$user->earning_balance + $bonusAmount;
        $user->save();

        DB::table('user_share_bonuses')->insert([
            'user_id' => $user->id,
            'bonus_amount' => $bonusAmount,
            'share_type' => 'facebook',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        DB::commit();

        return response()->json([
            'status' => 'success',
            'message' => 'Share bonus added successfully.'
        ]);

    } catch (\Exception $e) {
        DB::rollBack();

        return response()->json([
            'status' => 'error',
            'message' => $e->getMessage()
        ], 500);
    }
}

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show($id)
    {
        //
    }

    public function edit()
    {
        $countries = Country::orderBy('name', 'ASC')->get();
        return view('user.pages.profile-manage', compact('countries'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|min:3|max:50',
            'seller_skills' => 'nullable|max:255',
            'seller_experience_level' => 'nullable|max:100',
            'seller_bio' => 'nullable|max:2000',
        ]);

        $user = User::find($id);

        if (!$user || Auth::id() != $user->id) {
            abort(403);
        }

        if (Auth::user()->code == NULL) {
            $last_ac = User::select('id')->latest()->first();
            if (isset($last_ac)) {
                $code = sprintf('%04d', $last_ac->id + 1000001);
            } else {
                $code = sprintf('%04d', 1000001);
            }
            $user->code = $code;
        }

        $user->name = $request->name;
        $user->phone = $request->phone;
        $user->seller_skills = $request->seller_skills;
        $user->seller_experience_level = $request->seller_experience_level;
        $user->seller_bio = $request->seller_bio;

        $image = $request->file('image');
        if ($image) {
            if ($user->image && file_exists($user->image)) {
                @unlink($user->image);
            }

            if (!file_exists('backend/img/user/')) {
                @mkdir('backend/img/user/', 0777, true);
            }

            $image_name = Str::random(20);
            $ext = strtolower($image->getClientOriginalExtension());
            $image_full_name = $image_name . '.' . $ext;
            $upload_path = 'backend/img/user/';
            $image_url = $upload_path . $image_full_name;
            $image->move($upload_path, $image_full_name);
            $user->image = $image_url;
        }

        if ($request->password != '') {
            $user->password = Hash::make($request->password);
        }

        $user->save();

        return redirect()->back()->with('message', 'Profile updated successfully!');
    }

    public function destroy($id)
    {
        //
    }
}