<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Admin\MainWallet;
use App\Models\Admin\WithdrawFee;
use App\Models\User;
use App\Models\Withdraw;
use App\Models\WithdrawHeadline;
use App\Models\WithdrawMethod;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class UserWithdrawController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(is_user_suspend(Auth::user()->id) == 1){
            Auth::logout();
            return redirect()->route('login');
        }
        
        $withdraws = Withdraw::where('user_id', Auth::user()->id)->latest()->get();
        $headlines = WithdrawHeadline::all();
        return view('user.pages.withdraw', compact('withdraws', 'headlines'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(is_user_suspend(Auth::user()->id) == 1){
            Auth::logout();
            return redirect()->route('login');
        }
        
        $withdraw_fee = WithdrawFee::latest()->first();
        $methods = WithdrawMethod::where('status', 1)->get();
        $headlines = WithdrawHeadline::all();
        return view('user.pages.new-withdraw', compact('withdraw_fee', 'methods', 'headlines'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
{
    if(is_user_suspend(Auth::user()->id) == 1){
        Auth::logout();
        return redirect()->route('login');
    }

    $request->validate([
        'amount' => 'required|numeric|min:1',
        'account_type' => 'required',
        'account_no' => 'required',
    ]);

    $user = User::find(Auth::user()->id);
    $withdraw_fee = WithdrawFee::latest()->first();

    $amount = (float) $request->amount;

    // ❌ insufficient balance
    if($withdraw_fee->minimum_withdraw > $amount || $user->earning_balance < $amount){
        return redirect()->back()->with('error','You have no sufficient balance for withdraw.');
    }

    DB::beginTransaction();

    try {

        // 🔻 deduct user earning
        $user->earning_balance = $user->earning_balance - $amount;
        $user->save();

        // 🔺 add to main wallet
        $main_wallet = MainWallet::latest()->first();
        $main_wallet->amount = $main_wallet->amount + $amount;
        $main_wallet->save();

        // 💾 save withdraw request
        $withdraw = new Withdraw();
        $withdraw->user_id = $user->id;
        $withdraw->amount = $amount;
        $withdraw->charge = $request->withdraw_charge ?? 0;
        $withdraw->admin_fee = $request->admin_fee ?? 0;
        $withdraw->account_type = $request->account_type;
        $withdraw->account_no = $request->account_no;

        // 🔥 IMPORTANT FIX
        $withdraw->approval = 0; // pending

        $withdraw->save();

        DB::commit();

        return redirect()->route('user.withdraw')->with('message','Withdraw request submitted (Pending).');

    } catch (\Exception $e) {

        DB::rollBack();

        return redirect()->back()->with('error','Withdraw failed: '.$e->getMessage());
    }
}

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
