<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class UserReferralController extends Controller
{
    public function index()
    {
        $title = "Referral Link";
        $user = Auth::user();

        $referralLink = url('/register/' . $user->code);

        $totalReferrals = User::where('rfered_by', $user->id)->count();
        $activeReferrals = User::where('rfered_by', $user->id)
            ->where('referral_activated', 1)
            ->count();

        $depositCommission = (float) User::where('rfered_by', $user->id)->sum('deposit_commision_from_refer');
        $earningCommission = (float) User::where('rfered_by', $user->id)->sum('earning_commision_from_refer');
        $milestoneBonus = (float) $user->referral_milestone_bonus;

        $activationBonus = (float) DB::table('referral_reward_logs')
            ->where('referrer_id', $user->id)
            ->whereIn('type', ['activation_bonus', 'marketplace_bonus'])
            ->sum('amount');

        $totalReferralIncome = $depositCommission + $earningCommission + $milestoneBonus + $activationBonus;

        $nextMilestoneTarget = null;
        $nextMilestoneReward = 0;

        foreach ([5, 10, 20, 50] as $target) {
            if ($activeReferrals < $target) {
                $nextMilestoneTarget = $target;
                $nextMilestoneReward = referral_milestone_amount($target);
                break;
            }
        }

        $progressPercent = 100;
        if ($nextMilestoneTarget) {
            $previousTarget = 0;
            foreach ([5, 10, 20, 50] as $target) {
                if ($target < $nextMilestoneTarget) {
                    $previousTarget = $target;
                }
            }

            $range = $nextMilestoneTarget - $previousTarget;
            $current = max(0, $activeReferrals - $previousTarget);
            $progressPercent = $range > 0 ? min(100, round(($current / $range) * 100)) : 0;
        }

        $recentRewards = DB::table('referral_reward_logs')
            ->where('referrer_id', $user->id)
            ->latest('id')
            ->limit(10)
            ->get();

        return view('user.pages.referral', compact(
            'title',
            'referralLink',
            'totalReferrals',
            'activeReferrals',
            'depositCommission',
            'earningCommission',
            'milestoneBonus',
            'activationBonus',
            'totalReferralIncome',
            'nextMilestoneTarget',
            'nextMilestoneReward',
            'progressPercent',
            'recentRewards'
        ));
    }

    public function view_list()
    {
        $title = "Referral Users";

        $datas = User::where('rfered_by', Auth::user()->id)
            ->latest()
            ->paginate(25);

        return view('user.pages.referral-user', compact('title', 'datas'));
    }

    public function processActivationBonus($referredUserId)
    {
        $user = User::find($referredUserId);

        if (!$user || !$user->rfered_by) {
            return;
        }

        if ((int) $user->referral_activated === 1 && (int) $user->referral_activation_bonus_given === 1) {
            return;
        }

        $referrer = User::find($user->rfered_by);

        if (!$referrer) {
            return;
        }

        $bonus = referral_activation_bonus_amount();

        DB::transaction(function () use ($user, $referrer, $bonus) {
            $referrer->deposit_balance = (float) $referrer->deposit_balance + $bonus;
            $referrer->save();

            $user->referral_activated = 1;
            $user->referral_activation_bonus_given = 1;
            $user->save();

            DB::table('referral_reward_logs')->insert([
                'referrer_id' => $referrer->id,
                'referred_user_id' => $user->id,
                'type' => 'activation_bonus',
                'amount' => $bonus,
                'note' => 'First activation bonus for referred user.',
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        });

        $this->processMilestoneBonus($referrer->id);
    }

    public function processMarketplaceBonus($referredUserId)
    {
        $user = User::find($referredUserId);

        if (!$user || !$user->rfered_by) {
            return;
        }

        $referrer = User::find($user->rfered_by);

        if (!$referrer) {
            return;
        }

        $existing = DB::table('referral_reward_logs')
            ->where('referrer_id', $referrer->id)
            ->where('referred_user_id', $user->id)
            ->where('type', 'marketplace_bonus')
            ->exists();

        if ($existing) {
            return;
        }

        $bonus = referral_marketplace_bonus_amount();

        DB::transaction(function () use ($user, $referrer, $bonus) {
            $referrer->deposit_balance = (float) $referrer->deposit_balance + $bonus;
            $referrer->save();

            DB::table('referral_reward_logs')->insert([
                'referrer_id' => $referrer->id,
                'referred_user_id' => $user->id,
                'type' => 'marketplace_bonus',
                'amount' => $bonus,
                'note' => 'First marketplace order bonus for referred user.',
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        });
    }

    public function processMilestoneBonus($referrerId)
    {
        $referrer = User::find($referrerId);

        if (!$referrer) {
            return;
        }

        $activeCount = User::where('rfered_by', $referrerId)
            ->where('referral_activated', 1)
            ->count();

        foreach ([5, 10, 20, 50] as $target) {
            $bonus = referral_milestone_amount($target);

            if ($activeCount >= $target && $bonus > 0) {
                $exists = DB::table('referral_reward_logs')
                    ->where('referrer_id', $referrerId)
                    ->where('type', 'milestone_bonus')
                    ->where('note', 'Milestone bonus for ' . $target . ' active referrals.')
                    ->exists();

                if (!$exists) {
                    DB::transaction(function () use ($referrer, $bonus, $target) {
                        $referrer->deposit_balance = (float) $referrer->deposit_balance + $bonus;
                        $referrer->referral_milestone_bonus = (float) $referrer->referral_milestone_bonus + $bonus;
                        $referrer->save();

                        DB::table('referral_reward_logs')->insert([
                            'referrer_id' => $referrer->id,
                            'referred_user_id' => $referrer->id,
                            'type' => 'milestone_bonus',
                            'amount' => $bonus,
                            'note' => 'Milestone bonus for ' . $target . ' active referrals.',
                            'created_at' => now(),
                            'updated_at' => now(),
                        ]);
                    });
                }
            }
        }
    }
}