<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Admin\MainWallet;
use App\Models\Admin\Website;
use App\Models\BoostCategory;
use App\Models\BoostPackageHeadline;
use App\Models\User;
use App\Models\api_boost_jobs;
use App\Models\UserBoostPackage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;


class BoostPackageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $headlines = BoostPackageHeadline::all();
        $datas = api_boost_jobs::where('user_id',Auth::user()->id)->latest()->paginate(25);
        return view('user.pages.boost-package.index', compact('datas','headlines'));
        
        
        // old Script 
        // $datas = UserBoostPackage::where('user_id', Auth::user()->id)->latest()->paginate(25);
        // $headlines = BoostPackageHeadline::all();
        // $title = 'Order History';
        // $ordered = api_boost_jobs::where('user_id',Auth::user()->id)->latest()->paginate(25);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categorys = BoostCategory::orderBy('id', 'ASC')->get();
        $headlines = BoostPackageHeadline::all();
        $title = 'Add new Boost';

        return view('user.pages.boost-package.create', compact('categorys', 'title', 'headlines'));
    }






public function process($id)
{
    // আপনার প্রসেসিং লজিক এখানে থাকবে
    //$boost_package = UserBoostPackage::find($id);
    $boost_package = api_boost_jobs::find($id);
    
    if ($boost_package) {
        $boost_package->status = 1; // Process status
        $boost_package->save();

        return redirect()->back()->with('message', 'Boost package processed successfully.');
    } else {
        return redirect()->back()->with('error', 'Boost package not found.');
    }
}



public function reject(Request $request, $id)
{
    // আপনি যে ডাটার উপর ভিত্তি করে রিজেকশন করবেন তা হ্যান্ডেল করুন
    //$boostPackage = UserBoostPackage::find($id);
    $boostPackage = api_boost_jobs::find($id);
    
    if($boostPackage) {
        // রিজেকশন কারণ সংরক্ষণ করুন
        $boostPackage->status = 3; // 3 রিজেকশন স্ট্যাটাস নির্দেশ করছে
        $boostPackage->reason = $request->reason;
        $boostPackage->save();

        return redirect()->back()->with('message', 'Boost package rejected successfully.');
    }

    return redirect()->back()->with('error', 'Boost package not found.');
}





    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    { 
        // dd($request);
        $request->validate([
            'service_id' => 'required',
            'work_need' => 'required',
        ]);
        // Fetch the service list from the API
        $services = smm_get_services();
    // dd($services);
        // Find the selected service
        $selectedService = null;
        foreach ($services as $category => $service) {
            if($service['service'] == $request->service_id){
                $selectedService = $service;
            }
        }
        if(!$selectedService){
            return redirect()->back()->with('error','Service Not Found');
        }
        if($selectedService['min'] > $request->work_need){
            return redirect()->back()->with('error','Minimum Charge Not Found');
        }
        if($selectedService['max'] < $request->work_need){
            return redirect()->back()->with('error','Max Charge Over');
        }
        // Calculate the cost
        $ratePerThousand = $selectedService['rate']; // Cost per 1000 units
        $unitCost = $ratePerThousand / 1000;
        $totalCost = $request->work_need * $unitCost;
        $totalCost += $totalCost * 0.03;
        
        
        if(Auth::user()->deposit_balance < $totalCost){
            return redirect()->back()->with('error','You have no sufficient balance for job.');
        }
        // Take The Balance From Customer 
        $user_balance = User::find(Auth::user()->id);
        $user_balance->deposit_balance = $user_balance->deposit_balance - $totalCost;
        $user_balance->update();
        // Add Jo to the Database 
        $add_job = new api_boost_jobs();
        $add_job->user_id = Auth::user()->id;
        $add_job->service_id = $selectedService['service'];
        $add_job->name = $selectedService['name'];
        $add_job->category = $selectedService['category'];
        $add_job->link = $request->link;
        $add_job->type = $selectedService['type'];
        $add_job->rate = $selectedService['rate'];
        $add_job->limit_min = $selectedService['min'];
        $add_job->limit_max = $selectedService['max'];
        $add_job->order_qty = $request->work_need;
        $add_job->order_charge = $totalCost;
        $status = $add_job->save();

        if($status){
            return redirect()->back()->with('message','Boost Package added successfully');
        }else{
            return redirect()->back()->with('error','Boost Package added unsuccessful');
        }
        
        //************************
           // Old Script 
        //************************
        
        // $request->validate([
        //     'category_id' => 'required',
        //     'sub_category' => 'required',
        //     'work_need' => 'required',
        //     'cost' => 'required',
        // ]);

        // $website = Website::latest()->first();

        // $cost = $request->cost;
        // if(Auth::user()->deposit_balance < $cost){
        //     return redirect()->back()->with('error','You have no sufficient balance for job.');
        // }else{
        //     $user_balance = User::find(Auth::user()->id);
        //     $user_balance->deposit_balance = $user_balance->deposit_balance - $cost;
        //     $user_balance->save();

        //     $check_main_wallet = MainWallet::latest()->first();
        //     $main_wallet = MainWallet::find($check_main_wallet->id);
        //     $main_wallet->amount = $main_wallet->amount + $cost;
        //     $main_wallet->save();
        // }

        // $last_ac = UserBoostPackage::select('id')->latest()->first();
        // if (isset($last_ac)) {
        //     $code = sprintf('%04d', $last_ac->id + 1000001);
        // } else {
        //     $code = sprintf('%04d', 1000001);
        // }

        // $boost_package = new UserBoostPackage();
        // $boost_package->code = $code;
        // $boost_package->description = $request->description;
        // $boost_package->link = $request->link;
        // $boost_package->category_id = $request->category_id;
        // $boost_package->sub_category = $request->sub_category;
        // $boost_package->base_cost = $request->base_cost;
        // $boost_package->unit_cost = $request->unit_cost;
        // $boost_package->work_need = $request->work_need;
        // $boost_package->cost = $request->cost;
        // $boost_package->user_id = Auth::user()->id;
        // $boost_package->save();

        // return redirect()->back()->with('message','Boost Package added successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $boost_package = UserBoostPackage::find($id);
        $headlines = BoostPackageHeadline::all();
        $title = 'Update Boost Package';

        return view('user.pages.boost-package.edit', compact('boost_package', 'title', 'headlines'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'description' => 'required',
        ]);

        $boost_package = UserBoostPackage::find($id);
        $boost_package->description = $request->description;
        $boost_package->save();

        return redirect()->back()->with('message','Boost Package updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
