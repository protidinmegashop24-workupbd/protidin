<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class LoginController extends Controller
{
    use AuthenticatesUsers;

    protected $redirectTo = '/';

    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    public function login(Request $request)
    {
        $input = $request->all();

        if (site_info()->captcha_verify_active == 1) {
            $messages = [
                'g-recaptcha-response.required' => 'You must check the Captcha.',
                'g-recaptcha-response.captcha' => 'Captcha error! try again later or contact site admin.',
            ];

            $validator = Validator::make($request->all(), [
                'g-recaptcha-response' => 'required|captcha'
            ], $messages);

            if ($validator->fails()) {
                return redirect('login')->withErrors($validator)->withInput();
            }
        }

        if (auth()->attempt(['email' => $input['phone'], 'password' => $input['password']])) {
            return $this->handleAuthenticatedUser($request);
        }

        if (auth()->attempt(['phone' => $input['phone'], 'password' => $input['password']])) {
            return $this->handleAuthenticatedUser($request);
        }

        return redirect()->back();
    }

    protected function handleAuthenticatedUser(Request $request)
    {
        $user = User::find(auth()->user()->id);

        if (!$user) {
            Auth::logout();
            return redirect()->route('login');
        }

        if ($user->is_ban == 1) {
            Auth::logout();
            $request->session()->put('login_erro', 'This account is ban! Please contact with authority');
            return redirect()->back();
        }

        if ($user->is_suspended == 1) {
            if ($user->suspend_release && $user->suspend_release <= Carbon::now()) {
                $user->is_suspended = 0;
                $user->save();
            } else {
                Auth::logout();
                $request->session()->put('login_erro', 'This account is suspended! Please contact with authority');
                return redirect()->back();
            }
        }

        // OTP / Email verify check for normal users
if ($user->role_id == 3) {
    if ((int)$user->otp_verified !== 1 || empty($user->email_verified_at)) {
        Auth::logout();
        return redirect()->route('otp.verify', ['email' => $user->email])
            ->withErrors(['otp' => 'Please verify your email with OTP before login.']);
    }
}

        if ($user->ip_address == null) {
            $user->ip_address = $request->ip();
        }

        $user->activity = 1;
        $user->save();

        $request->session()->put('login_erro', '');

        if ($user->role_id == 1 || $user->role_id == 2) {
            return redirect()->route('admin.dashboard');
        }

        if ($user->role_id == 3) {
            if ($request->session()->has('url.intended')) {
                return redirect()->intended();
            }

            return redirect()->route('user.dashboard');
        }

        return redirect()->route('home');
    }
}