<?php

namespace App\Providers;

use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;
use Illuminate\Pagination\Paginator;

use Config;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Schema::defaultStringLength(191);
        Paginator::useBootstrap();
        
        $data = [
            'driver'            => env('MAIL_MAILER', 'smtp'),
            'host'              => env('MAIL_HOST', 'smtp.gmail.com'),
            'port'              => env('MAIL_PORT', 587),
            'encryption'        => env('MAIL_ENCRYPTION', 'tls'),
            'username'          => env('MAIL_USERNAME', 'kmovi52@gmail.com'),
            'password'          => env('MAIL_PASSWORD', 'pecn rhdp wtgt bcmm'),
                    'from'              => [
                        'address'=> website_info()->mail_from,
                        'name'   => website_info()->title
                    ]
                ];
        Config::set('mail',$data);
    }
}
